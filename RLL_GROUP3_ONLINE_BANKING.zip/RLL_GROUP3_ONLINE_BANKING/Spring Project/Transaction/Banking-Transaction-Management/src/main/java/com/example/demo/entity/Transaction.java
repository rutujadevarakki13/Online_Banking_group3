package com.example.demo.entity;

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Transaction {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private int accountNumber;
    private double amount;
    private LocalDateTime timestamp;
    public enum TransactionType {
        DEPOSIT, WITHDRAWAL, TRANSFER
    }
    private TransactionType type;

    public void setType(TransactionType type) {
        this.type = type;
    }
    private int sourceAccountNumber; 
    private int targetAccountNumber;

}
