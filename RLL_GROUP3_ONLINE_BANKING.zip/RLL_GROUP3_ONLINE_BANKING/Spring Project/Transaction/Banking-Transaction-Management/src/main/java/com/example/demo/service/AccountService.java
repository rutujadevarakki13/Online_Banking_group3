package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Account;
import com.example.demo.repo.AccountRepository;

@Service
public class AccountService {

	@Autowired
	private AccountRepository accountRepository;

	public Account depositAmount(int accountNumber, double amount) {
		Account account = accountRepository.findByAccountNumber(accountNumber);
		if (account != null) {
			double currentBalance = account.getBalance();
			account.setBalance(currentBalance + amount);
			return accountRepository.save(account);
		}
		return null;
	}

	public Account withdrawAmount(int accountNumber, double amount) {
		Account account = accountRepository.findByAccountNumber(accountNumber);
		if (account != null && account.isActive()) {
			double currentBalance = account.getBalance();
			if (currentBalance >= amount) {
				account.setBalance(currentBalance - amount);
				return accountRepository.save(account);
			} else {
				throw new IllegalArgumentException("Insufficient balance");
			}
		}
		return null;
	}

	public double checkBalanceByAccountNumber(int accountNumber) {
		Account account = accountRepository.findByAccountNumber(accountNumber);
		if (account != null) {
			return account.getBalance();
		}
		throw new IllegalArgumentException("Account not found");
	}

	public Account createAccount(Account account) {
		return accountRepository.save(account);
	}

}
