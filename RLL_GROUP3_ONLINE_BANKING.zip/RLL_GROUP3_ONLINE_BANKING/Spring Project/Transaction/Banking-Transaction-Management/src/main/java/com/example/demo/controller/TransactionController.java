package com.example.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Account;
import com.example.demo.entity.Transaction;
import com.example.demo.service.AccountService;
import com.example.demo.service.TransactionService;

@RestController
@RequestMapping("/transactions")
public class TransactionController {

	@Autowired
	private TransactionService transactionService;

	@Autowired
	private AccountService accountService;

	@PostMapping("/create") // This maps to /accounts/create using POST method
	public ResponseEntity<String> createAccount(@RequestBody Account account) {
		try {
			Account createdAccount = accountService.createAccount(account);
			return ResponseEntity.status(HttpStatus.CREATED)
					.body("Account created successfully with ID: " + createdAccount.getId());
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body("Failed to create account: " + e.getMessage());
		}
	}

	@PutMapping("/deposit/{accountNumber}/{amount}")
	public ResponseEntity<String> deposit(@PathVariable int accountNumber, @PathVariable double amount) {
		try {
			transactionService.deposit(accountNumber, amount);
			return ResponseEntity.ok("Deposit successful.");
		} catch (IllegalArgumentException e) {
			return ResponseEntity.badRequest().body(e.getMessage());
		}
	}

	@PutMapping("/withdraw/{accountNumber}/{amount}")
	public ResponseEntity<String> withdraw(@PathVariable int accountNumber, @PathVariable double amount) {
		try {
			transactionService.withdraw(accountNumber, amount);
			return ResponseEntity.ok("Withdrawal successful.");
		} catch (IllegalArgumentException e) {
			return ResponseEntity.badRequest().body(e.getMessage());
		}
	}

	@PostMapping("/transfer/{sourceAccountNumber}/{targetAccountNumber}/{amount}")
	public ResponseEntity<String> transfer(@PathVariable int sourceAccountNumber, @PathVariable int targetAccountNumber,
			@PathVariable double amount) {
		try {
			transactionService.transfer(sourceAccountNumber, targetAccountNumber, amount);
			return ResponseEntity.ok("Transfer successful.");
		} catch (IllegalArgumentException e) {
			return ResponseEntity.badRequest().body(e.getMessage());
		}
	}

	@GetMapping("/balance/{accountNumber}")
	public ResponseEntity<String> checkBalance(@PathVariable int accountNumber) {
		try {
			double balance = accountService.checkBalanceByAccountNumber(accountNumber);
			return ResponseEntity.ok("Your account balance is: " + balance);
		} catch (IllegalArgumentException e) {
			return ResponseEntity.badRequest().body(e.getMessage());
		}
	}

	@GetMapping("/all")
	public ResponseEntity<List<Transaction>> getAllTransactions() {
		List<Transaction> transactions = transactionService.getAllTransactions();
		return ResponseEntity.ok(transactions);
	}

	@GetMapping("/{transactionId}")
	public ResponseEntity<Transaction> getTransactionById(@PathVariable Long transactionId) {
		Optional<Transaction> transaction = transactionService.getTransactionById(transactionId);
		if (transaction.isPresent()) {
			return ResponseEntity.ok(transaction.get());
		} else {
			return ResponseEntity.notFound().build();
		}
	}

//    @GetMapping("/account/{accountNumber}")
//    public List<Transaction> getAllTransactionsByAccountNumber(@PathVariable int accountNumber) {
//        return transactionService.getAllTransactionsByAccountNumber(accountNumber);
//    }

}