package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.ChequeRequest;
import com.example.demo.service.ChequeRequestService;


@RestController
@RequestMapping("/cheque-requests")
public class ChequeRequestController {
	
	@Autowired
	private ChequeRequestService chequeRequestService;
	
	  // Create a cheque book request
    @PostMapping("/create")
    public ResponseEntity<ChequeRequest> createChequeRequest(@RequestBody ChequeRequest chequeRequest) {
        ChequeRequest createdRequest = chequeRequestService.createChequeRequest(chequeRequest);
        return ResponseEntity.ok(createdRequest);
    }

    // Get pending cheque book requests
    @GetMapping("/pending")
    public ResponseEntity<List<ChequeRequest>> getPendingChequeRequests() {
        List<ChequeRequest> pendingRequests = chequeRequestService.getPendingChequeRequests();
        return ResponseEntity.ok(pendingRequests);
    }

    // Get cheque book requests by account ID
    @GetMapping("/account/{accountNumber}")
    public ResponseEntity<List<ChequeRequest>> getChequeRequestsByAccount(@PathVariable int accountNumber) {
        List<ChequeRequest> requests = chequeRequestService.getChequeRequestsByAccount(accountNumber);
        return ResponseEntity.ok(requests);
    }
   

    // Authorize a cheque book request
    @PostMapping("/authorize/{requestId}")
    public ResponseEntity<String> authorizeChequeRequest(@PathVariable Long requestId) {
        chequeRequestService.authorizeChequeRequest(requestId);
        return ResponseEntity.ok("Cheque book request authorized.");
    }

}
