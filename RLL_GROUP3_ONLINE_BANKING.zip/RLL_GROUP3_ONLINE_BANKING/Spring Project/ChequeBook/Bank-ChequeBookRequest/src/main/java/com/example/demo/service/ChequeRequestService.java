package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import com.example.demo.entity.ChequeRequest;
import com.example.demo.repo.ChequeRequestRepo;


@Service
public class ChequeRequestService {

	@Autowired
	private ChequeRequestRepo chequeRequestRepo;
	
	 public ChequeRequest createChequeRequest(ChequeRequest chequeRequest) {
	        // Implement logic to create a cheque book request
	        return chequeRequestRepo.save(chequeRequest);
	    }

	    public List<ChequeRequest> getPendingChequeRequests() {
	        return chequeRequestRepo.findByAuthorized(false);
	    }

	    public List<ChequeRequest> getChequeRequestsByAccount(int accountNumber) {
	        return chequeRequestRepo.findByAccountNumber(accountNumber);
	    }

	    public void authorizeChequeRequest(Long requestId) {
	        Optional<ChequeRequest> requestOptional = chequeRequestRepo.findById(requestId);
	        if (requestOptional.isPresent()) {
	            ChequeRequest request = requestOptional.get();
	            request.setAuthorized(true);
	            chequeRequestRepo.save(request);
	        } else {
	            // Handle the case when the request with the given ID is not found
	        	throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Cheque book request with ID " + requestId + " not found");
	        }
	    }
}
