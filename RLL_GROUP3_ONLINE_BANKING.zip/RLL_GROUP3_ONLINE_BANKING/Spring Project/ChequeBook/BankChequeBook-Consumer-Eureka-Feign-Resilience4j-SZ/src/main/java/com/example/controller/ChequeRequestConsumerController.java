package com.example.controller;

import com.example.entity.ChequeRequest;
import com.example.proxy.ChequeRequestServiceProxy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;

import java.util.List;

@RestController
public class ChequeRequestConsumerController {

    @Autowired
    private ChequeRequestServiceProxy chequeRequestServiceProxy;

    private Logger log = LoggerFactory.getLogger(ChequeRequestConsumerController.class);

    @PostMapping("/cheque-requests/create")
    public ResponseEntity<ChequeRequest> createChequeRequest(@RequestBody ChequeRequest chequerequest) {
        log.debug("Creating a cheque request");
        ResponseEntity<ChequeRequest> response = chequeRequestServiceProxy.createChequeRequest(chequerequest);
        log.debug("Created cheque request: " + response.getBody());
        return response;
    }

    @GetMapping("/cheque-requests/pending")
    public ResponseEntity<List<ChequeRequest>> getPendingChequeRequests() {
        log.debug("Fetching pending cheque requests");
        ResponseEntity<List<ChequeRequest>> response = chequeRequestServiceProxy.getPendingChequeRequests();
        log.debug("Fetched pending cheque requests: " + response.getBody());
        return response;
    }

    @GetMapping("/cheque-requests/account/{accountNumber}")
    public ResponseEntity<List<ChequeRequest>> getChequeRequestsByAccount(@PathVariable int accountNumber) {
        log.debug("Fetching cheque requests by account number: " + accountNumber);
        ResponseEntity<List<ChequeRequest>> response = chequeRequestServiceProxy.getChequeRequestsByAccount(accountNumber);
        log.debug("Fetched cheque requests for account " + accountNumber + ": " + response.getBody());
        return response;
    }

    @PostMapping("/cheque-requests/authorize/{requestId}")
    public ResponseEntity<String> authorizeChequeRequest(@PathVariable Long requestId) {
        log.debug("Approving cheque request with ID: " + requestId);
        ResponseEntity<String> response = chequeRequestServiceProxy.authorizeChequeRequest(requestId);
        log.debug("cheque request approval response: " + response.getBody());
        return response;
    }
}
