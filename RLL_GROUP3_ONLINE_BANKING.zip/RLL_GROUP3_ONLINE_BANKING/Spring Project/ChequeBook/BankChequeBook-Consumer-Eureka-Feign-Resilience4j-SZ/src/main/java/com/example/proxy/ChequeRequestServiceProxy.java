package com.example.proxy;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.entity.ChequeRequest;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

@FeignClient(name = "cheque-service")
public interface ChequeRequestServiceProxy {

    @Retry(name = "cheque-service")
    @CircuitBreaker(name = "cheque-service", fallbackMethod = "fallbackCreateChequeRequest")
    @PostMapping("/cheque-requests/create")
    ResponseEntity<ChequeRequest> createChequeRequest(@RequestBody ChequeRequest chequerequest);

    @Retry(name = "cheque-service")
    @CircuitBreaker(name = "cheque-service", fallbackMethod = "fallbackGetPendingChequeRequest")
    @GetMapping("/cheque-requests/pending")
    ResponseEntity<List<ChequeRequest>> getPendingChequeRequests();

    @Retry(name = "cheque-service")
    @CircuitBreaker(name = "cheque-service", fallbackMethod = "fallbackGetChequeRequestsByAccount")
    @GetMapping("/cheque-requests/account/{accountNumber}")
    ResponseEntity<List<ChequeRequest>> getChequeRequestsByAccount(@PathVariable int accountNumber);

    @Retry(name = "cheque-service")
    @CircuitBreaker(name = "cheque-service", fallbackMethod = "fallbackAuthorizeChequeRequest")
    @PostMapping("/cheque-requests/authorize/{requestId}")
    ResponseEntity<String> authorizeChequeRequest(@PathVariable Long requestId);

    // Fallback methods for each Feign client method
    default ResponseEntity<String> fallbackCreateChequeRequest(ChequeRequest chequerequest, Throwable cause) {
        // Implement your fallback logic here
    	
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Fallback Message : The Create ChequeRequest Service is unavailable");
    }

    default ResponseEntity<String> fallbackGetPendingChequeRequest(Throwable cause) {
        // Implement your fallback logic here
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Fallback Message : The Pending Service is unavailable");
    }

    default ResponseEntity<String> fallbackGetChequeRequestsByAccount(int accountNumber, Throwable cause) {
        // Implement your fallback logic here
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Fallback Message : The ChequeRequest Service is unavailable");
    }

    default ResponseEntity<String> fallbackAuthorizeChequeRequest(Long requestId, Throwable cause) {
        // Implement your fallback logic here
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Fallback Message : The Authorize Service is unavailable");
    }
}
