package com.example.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.entity.Account;
import com.example.entity.BankUser;
import com.example.proxy.AccountServiceProxy;
import com.example.proxy.BankUserServiceProxy;

@RestController
public class BankUserRegistrationConsumerController {

	@Autowired
	private BankUserServiceProxy bankUserServicerProxy;

	@Autowired
	private AccountServiceProxy accountServiceProxy;

	private Logger log = LoggerFactory.getLogger(BankUserRegistrationConsumerController.class);

	@PostMapping("/users/create")
	public ResponseEntity<String> createUser(@RequestBody BankUser user) {
		log.debug("Creating a bank user");
		ResponseEntity<String> response = bankUserServicerProxy.createUser(user);
		log.debug("Created bank user: " + user);
		return response;
	}

	@PostMapping("/users/approve/{userId}")
	public ResponseEntity<String> approveUser(@PathVariable("userId") Long userId) {
		log.debug("Approving bank user with ID: " + userId);
		ResponseEntity<String> response = bankUserServicerProxy.approveUser(userId);
		log.debug("Approved bank user with ID: " + userId);
		return response;
	}

	@GetMapping("/users/{userId}")
	public ResponseEntity<BankUser> getUserById(@PathVariable("userId") Long userId) {
		log.debug("Fetching bank user by ID: " + userId);
		ResponseEntity<BankUser> response = bankUserServicerProxy.getUserById(userId);
		log.debug("Fetched bank user by ID: " + userId);
		return response;
	}

	@PostMapping("/create")
	public ResponseEntity<Account> createAccount(@RequestBody Account account) {
		log.debug("Creating an account");
		ResponseEntity<Account> response = accountServiceProxy.createAccount(account);
		log.debug("Created account: " + response.getBody());
		return response;
	}
}
