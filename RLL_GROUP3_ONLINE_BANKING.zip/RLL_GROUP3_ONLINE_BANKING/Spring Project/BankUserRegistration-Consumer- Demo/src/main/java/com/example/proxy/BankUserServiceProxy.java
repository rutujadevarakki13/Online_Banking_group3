package com.example.proxy;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.entity.BankUser;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

@FeignClient(name = "user-service")
public interface BankUserServiceProxy {

	@Retry(name = "user-service")
	@CircuitBreaker(name = "user-service", fallbackMethod = "fallbackCreateUser")
	@PostMapping("/users/create")
	ResponseEntity<String> createUser(@RequestBody BankUser user);

	@Retry(name = "user-service")
	@CircuitBreaker(name = "user-service", fallbackMethod = "fallbackGetAllUsers")
	@GetMapping("/users/all")
	ResponseEntity<List<BankUser>> getAllUsers();

	@Retry(name = "user-service")
	@CircuitBreaker(name = "user-service", fallbackMethod = "fallbackGetUserById")
	@GetMapping("/users/{userId}")
	ResponseEntity<BankUser> getUserById(@PathVariable("userId") Long userId);

	@Retry(name = "user-service")
	@CircuitBreaker(name = "user-service", fallbackMethod = "fallbackApproveUser")
	@PostMapping("/users/approve/{userId}")
	ResponseEntity<String> approveUser(@PathVariable("userId") Long userId);

	@Retry(name = "user-service")
	@CircuitBreaker(name = "user-service", fallbackMethod = "fallbackDeleteUser")
	@DeleteMapping("/users/delete/{userId}")
	ResponseEntity<String> deleteUser(@PathVariable("userId") Long userId);

	// Fallback methods for each Feign client method
	default ResponseEntity<String> fallbackCreateUser(BankUser user, Throwable cause) {
		// Implement your fallback logic here
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
				.body("Fallback Message: create User service is unavailable");
	}

	default ResponseEntity<String> fallbackGetAllUsers(Throwable cause) {
		// Implement your fallback logic here
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
				.body("Fallback Message: Get All Users service is unavailable");
	}

	default ResponseEntity<String> fallbackGetUserById(Long userId, Throwable cause) {
		// Implement your fallback logic here
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
				.body("Fallback Message: Get Users By Id service is unavailable");
	}

	default ResponseEntity<String> fallbackApproveUser(Long userId, Throwable cause) {
		// Implement your fallback logic here
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
				.body("Fallback Message: Approving Users service is unavailable");
	}

	default ResponseEntity<String> fallbackDeleteUser(Long userId, Throwable cause) {
		// Implement your fallback logic here
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
				.body("Fallback Message: Deleting service is unavailable");
	}
}
