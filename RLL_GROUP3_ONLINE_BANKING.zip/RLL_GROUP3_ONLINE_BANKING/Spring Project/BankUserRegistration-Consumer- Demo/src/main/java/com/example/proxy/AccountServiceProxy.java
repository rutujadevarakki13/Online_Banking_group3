package com.example.proxy;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.entity.Account;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

@FeignClient(name = "account-service")
public interface AccountServiceProxy {

	@Retry(name = "account-service")
	@CircuitBreaker(name = "account-service", fallbackMethod = "fallbackCreateAccount")
	@PostMapping("/accounts/create")
	ResponseEntity<Account> createAccount(@RequestBody Account account);

	@Retry(name = "account-service")
	@CircuitBreaker(name = "account-service", fallbackMethod = "fallbackDisableAccount")
	@PutMapping("/accounts/disable/{accountId}")
	ResponseEntity<String> disableAccount(@PathVariable("accountId") Long accountId);

	@Retry(name = "account-service")
	@CircuitBreaker(name = "account-service", fallbackMethod = "fallbackEnableAccount")
	@PutMapping("/accounts/enable/{accountId}")
	ResponseEntity<String> enableAccount(@PathVariable("accountId") Long accountId);

	@Retry(name = "account-service")
	@CircuitBreaker(name = "account-service", fallbackMethod = "fallbackGetAccount")
	@GetMapping("/accounts/{accountId}")
	ResponseEntity<Account> getAccount(@PathVariable("accountId") Long accountId);

	@Retry(name = "account-service")
	@CircuitBreaker(name = "account-service", fallbackMethod = "fallbackGetAllActiveAccounts")
	@GetMapping("/accounts/active")
	ResponseEntity<List<Account>> getAllActiveAccounts();

	@Retry(name = "account-service")
	@CircuitBreaker(name = "account-service", fallbackMethod = "fallbackDeleteAccount")
	@DeleteMapping("/accounts/delete/{accountNumber}")
	ResponseEntity<String> deleteAccountByAccountNumber(@PathVariable("accountNumber") int accountNumber);

	default ResponseEntity<String> fallbackCreateAccount(Account account, Throwable cause) {

		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
				.body("Fallback message: Creating Account Service is Unavailable");
	}

	default ResponseEntity<String> fallbackDisableAccount(Long accountId, Throwable cause) {

		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
				.body("Fallback message: Disabling Account Service is Unavailable");
	}

	default ResponseEntity<String> fallbackEnableAccount(Long accountId, Throwable cause) {

		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
				.body("Fallback message: Enable Account Service is Unavailable");
	}

	default ResponseEntity<String> fallbackGetAccount(Long accountId, Throwable cause) {

		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
				.body("Fallback message: Getting Account Service is Unavailable");
	}

	default ResponseEntity<String> fallbackGetAllActiveAccounts(Throwable cause) {

		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
				.body("Fallback message: Getting All Active Account Service is Unavailable");
	}

	default ResponseEntity<String> fallbackDeleteAccount(int accountNumber, Throwable cause) {

		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
				.body("Fallback message: Deleting Account Servvice is Unavailable");
	}
}