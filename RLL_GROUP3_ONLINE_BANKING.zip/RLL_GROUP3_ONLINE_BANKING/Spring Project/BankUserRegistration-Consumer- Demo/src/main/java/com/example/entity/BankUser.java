package com.example.entity;

public class BankUser {
	private Long id;
	private String cutomerIdNumber;
	public String getCutomerIdNumber() {
		return cutomerIdNumber;
	}

	public void setCutomerIdNumber(String cutomerIdNumber) {
		this.cutomerIdNumber = cutomerIdNumber;
	}

	private String username;
	private String password;
	private boolean approved;

	// Other attributes, getters, setters, etc.

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public boolean isApproved() {
		return approved;
	}

	public void setApproved(boolean approved) {
		this.approved = approved;
	}

	// Constructors, getters, setters, etc.
}
