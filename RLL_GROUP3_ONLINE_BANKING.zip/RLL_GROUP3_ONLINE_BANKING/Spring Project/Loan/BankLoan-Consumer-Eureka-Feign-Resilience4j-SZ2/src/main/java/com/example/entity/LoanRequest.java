package com.example.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
public class LoanRequest {

	private Long id;
    private int accountNumber;
    private double amount;
    private boolean status;
}
