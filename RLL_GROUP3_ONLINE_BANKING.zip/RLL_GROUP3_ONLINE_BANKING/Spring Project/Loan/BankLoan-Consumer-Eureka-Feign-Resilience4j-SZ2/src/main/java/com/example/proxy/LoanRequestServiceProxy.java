package com.example.proxy;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.entity.LoanRequest;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

@FeignClient(name = "loan-service")
public interface LoanRequestServiceProxy {

	@Retry(name = "loan-service")
	@CircuitBreaker(name = "loan-service", fallbackMethod = "fallbackCreateLoanRequest")
	@PostMapping("/loan-requests/create")
	ResponseEntity<LoanRequest> createLoanRequest(@RequestBody LoanRequest loanRequest);

	@Retry(name = "loan-service")
	@CircuitBreaker(name = "loan-service", fallbackMethod = "fallbackGetPendingLoanRequests")
	@GetMapping("/loan-requests/pending")
	ResponseEntity<List<LoanRequest>> getPendingLoanRequests();

	@Retry(name = "loan-service")
	@CircuitBreaker(name = "loan-service", fallbackMethod = "fallbackGetLoanRequestsByAccount")
	@GetMapping("/loan-requests/account/{accountNumber}")
	ResponseEntity<List<LoanRequest>> getLoanRequestsByAccount(@PathVariable int accountNumber);

	@Retry(name = "loan-service")
	@CircuitBreaker(name = "loan-service", fallbackMethod = "fallbackApproveLoanRequest")
	@PostMapping("/loan-requests/approve/{requestId}")
	ResponseEntity<String> approveLoanRequest(@PathVariable Long requestId);

	// Fallback methods for each Feign client method
	default ResponseEntity<String> fallbackCreateLoanRequest(LoanRequest loanRequest, Throwable cause) {
		// Implement your fallback logic here
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
				.body("Fallback Message : The Loan Creating Service is unavailable");
	}

	default ResponseEntity<String> fallbackGetPendingLoanRequests(Throwable cause) {
		// Implement your fallback logic here
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
				.body("Fallback Message : The Loan Pending Service is unavailable");
	}

	default ResponseEntity<String> fallbackGetLoanRequestsByAccount(int accountNumber, Throwable cause) {
		// Implement your fallback logic here
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
				.body("Fallback Message : The Loan Requesting By Account Service is unavailable");
	}

	default ResponseEntity<String> fallbackApproveLoanRequest(Long requestId, Throwable cause) {
		// Implement your fallback logic here
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
				.body("Fallback Message : The Loan Approving Service is unavailable");
	}
}
