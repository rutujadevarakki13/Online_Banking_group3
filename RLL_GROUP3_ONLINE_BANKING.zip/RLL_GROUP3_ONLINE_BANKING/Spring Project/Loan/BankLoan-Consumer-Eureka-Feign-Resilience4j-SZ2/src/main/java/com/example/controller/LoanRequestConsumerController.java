package com.example.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.entity.LoanRequest;
import com.example.proxy.LoanRequestServiceProxy;

@RestController
public class LoanRequestConsumerController {

    @Autowired
    private LoanRequestServiceProxy loanRequestServiceProxy;

    private Logger log = LoggerFactory.getLogger(LoanRequestConsumerController.class);

    @PostMapping("/loan-requests/create")
    public ResponseEntity<LoanRequest> createLoanRequest(@RequestBody LoanRequest loanRequest) {
        log.debug("Creating a loan request");
        ResponseEntity<LoanRequest> response = loanRequestServiceProxy.createLoanRequest(loanRequest);
        log.debug("Created loan request: " + response.getBody());
        return response;
    }

    @GetMapping("/loan-requests/pending")
    public ResponseEntity<List<LoanRequest>> getPendingLoanRequests() {
        log.debug("Fetching pending loan requests");
        ResponseEntity<List<LoanRequest>> response = loanRequestServiceProxy.getPendingLoanRequests();
        log.debug("Fetched pending loan requests: " + response.getBody());
        return response;
    }
   
    
    @GetMapping("/loan-requests/account/{accountNumber}")
    public ResponseEntity<List<LoanRequest>> getLoanRequestsByAccount(@PathVariable int accountNumber) {
        log.debug("Fetching loan requests by account number: " + accountNumber);
        ResponseEntity<List<LoanRequest>> response = loanRequestServiceProxy.getLoanRequestsByAccount(accountNumber);
        log.debug("Fetched loan requests for account " + accountNumber + ": " + response.getBody());
        return response;
    }

    @PostMapping("/loan-requests/approve/{requestId}")
    public ResponseEntity<String> approveLoanRequest(@PathVariable Long requestId) {
        log.debug("Approving loan request with ID: " + requestId);
        ResponseEntity<String> response = loanRequestServiceProxy.approveLoanRequest(requestId);
        log.debug("Loan request approval response: " + response.getBody());
        return response;
    }
}
