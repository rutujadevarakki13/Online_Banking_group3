package com.example.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.example.entity.BankUser;
import com.example.service.BankUserService;

@RestController
@RequestMapping("/users")
public class BankUserController {
	@Autowired
	private BankUserService userService;

	@PostMapping("/create")
	public ResponseEntity<String> createUser(@RequestBody BankUser user) {
		return userService.createUser(user);
	}

	@PutMapping("/update/{userId}")
	public ResponseEntity<String> updateUser(@PathVariable Long userId, @RequestBody BankUser updatedUser) {
		return userService.updateUser(userId, updatedUser);
	}

	@GetMapping("/all")
	public ResponseEntity<List<BankUser>> getAllUsers() {
		return userService.getAllUsers();
	}

	@GetMapping("/pending")
	public List<BankUser> getPendingUsers() {
		return userService.getPendingUsers();
	}

	@GetMapping("/approved")
	public List<BankUser> getApprovedUsers() {
		return userService.getApprovedUsers();
	}

	@GetMapping("/{userId}")
	public ResponseEntity<BankUser> getUserById(@PathVariable Long userId) {
		return userService.getUserById(userId);
	}

	@PostMapping("/approve/{userId}")
	public ResponseEntity<String> approveUser(@PathVariable Long userId) {
		return userService.approveUser(userId);
	}

	@DeleteMapping("/delete/{userId}")
	public ResponseEntity<String> deleteUser(@PathVariable Long userId) {
		return userService.deleteUser(userId);
	}
}
