package com.example.repositories;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import com.example.entity.BankUser;

public interface BankUserRepository extends JpaRepository<BankUser, Long> {
	List<BankUser> findByApproved(boolean approved);

	Optional<BankUser> findByIdAndApproved(Long id, boolean approved);

	List<BankUser> findAllByApproved(boolean approved); // Custom query method for fetching users by approval status
}
