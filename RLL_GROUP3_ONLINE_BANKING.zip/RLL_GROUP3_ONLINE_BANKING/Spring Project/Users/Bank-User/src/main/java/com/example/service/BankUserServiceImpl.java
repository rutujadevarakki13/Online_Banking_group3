package com.example.service;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.example.entity.BankUser;
import com.example.repositories.BankUserRepository;

@Service
public class BankUserServiceImpl implements BankUserService {
	@Autowired
	private BankUserRepository userRepository;
	
	private int lastGeneratedCustomerID = 10000000;
	
	private String generateCustomerID() {
		lastGeneratedCustomerID++;
		return String.valueOf(lastGeneratedCustomerID);
	}

	@Override
	public ResponseEntity<String> createUser(BankUser user) {
		try {
			// Logic to create a new user
			user.setCutomerIdNumber(generateCustomerID());
			user.setApproved(false); // Initially, the user is not approved
			userRepository.save(user);

			return ResponseEntity.status(HttpStatus.CREATED).body("User created successfully");
		} catch (Exception e) {
			// Handle the exception and provide a custom error message
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body("User creation failed: " + e.getMessage());
		}
	}

	@Override
	public ResponseEntity<String> updateUser(Long userId, BankUser updatedUser) {
		try {
			// Logic to update user information
			BankUser existingUser = userRepository.findById(userId)
					.orElseThrow(() -> new RuntimeException("User not found with id: " + userId));

			existingUser.setUsername(updatedUser.getUsername());
			existingUser.setPassword(updatedUser.getPassword());
			userRepository.save(existingUser);

			return ResponseEntity.ok("User updated successfully");
		} catch (Exception e) {
			// Handle the exception and provide a custom error message
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body("User update failed: " + e.getMessage());
		}
	}

	@Override
	public ResponseEntity<List<BankUser>> getAllUsers() {
		try {
			// Logic to fetch all users
			List<BankUser> users = userRepository.findAll();

			if (users.isEmpty()) {
				return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Collections.emptyList());
			}

			return ResponseEntity.ok(users);
		} catch (Exception e) {
			// Handle the exception and provide a custom error message
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Collections.emptyList());
		}
	}

	@Override
	public List<BankUser> getPendingUsers() {
		try {
			// Add debug logging before fetching pendingUsers
			System.out.println("Before fetching Pending Users");

			// Logic to fetch pending user approvals
			List<BankUser> pendingUsers = userRepository.findAllByApproved(false);

			// Add more debug logging for each user
			for (BankUser user : pendingUsers) {
				System.out.println("Pending User ID: " + user.getId());
			}

			return pendingUsers;
		} catch (Throwable e) {
			throw new RuntimeException("Failed to fetch pending users: " + e.getMessage(), e);
		}
	}

	@Override
	public List<BankUser> getApprovedUsers() {
		try {
			// Logic to fetch approved users
			List<BankUser> approvedUsers = userRepository.findAllByApproved(true);
			return approvedUsers;
		} catch (Exception e) {
			throw new RuntimeException("Failed to fetch approved users: " + e.getMessage(), e);
		}
	}

	@Override
	public ResponseEntity<BankUser> getUserById(Long userId) {
		try {
			// Logic to fetch a user by ID
			Optional<BankUser> userOptional = userRepository.findById(userId);

			if (userOptional.isPresent()) {
				return ResponseEntity.ok(userOptional.get());
			} else {
				return ResponseEntity.notFound().build();
			}
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
		}
	}

	@Override
	public ResponseEntity<String> approveUser(Long userId) {
		try {
			// Logic to approve a user
			Optional<BankUser> userOptional = userRepository.findById(userId);

			if (userOptional.isPresent()) {
				BankUser userToApprove = userOptional.get();
				userToApprove.setApproved(true);
				userRepository.save(userToApprove);

				return ResponseEntity.ok("User approved successfully");
			} else {
				return ResponseEntity.notFound().build();
			}
		} catch (Exception e) {
			throw new RuntimeException("User approval failed: " + e.getMessage(), e);
		}
	}

	@Override
	public ResponseEntity<String> deleteUser(Long userId) {
		try {
			// Logic to delete a user
			userRepository.deleteById(userId);

			return ResponseEntity.ok("User deleted successfully");
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body("User deletion failed: " + e.getMessage());
		}
	}
}
