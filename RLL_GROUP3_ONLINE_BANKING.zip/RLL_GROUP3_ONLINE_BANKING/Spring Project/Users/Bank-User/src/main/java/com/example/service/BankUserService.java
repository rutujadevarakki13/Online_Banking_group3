package com.example.service;

import java.util.List;
import org.springframework.http.ResponseEntity;
import com.example.entity.BankUser;

public interface BankUserService {
	ResponseEntity<String> createUser(BankUser user);

	ResponseEntity<String> updateUser(Long userId, BankUser updatedUser);

	ResponseEntity<List<BankUser>> getAllUsers();

	List<BankUser> getPendingUsers();

	List<BankUser> getApprovedUsers();

	ResponseEntity<BankUser> getUserById(Long userId);

	ResponseEntity<String> approveUser(Long userId);

	ResponseEntity<String> deleteUser(Long userId);
}
