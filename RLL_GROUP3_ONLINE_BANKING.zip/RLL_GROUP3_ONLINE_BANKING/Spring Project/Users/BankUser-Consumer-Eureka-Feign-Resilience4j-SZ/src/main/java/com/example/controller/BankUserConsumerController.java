package com.example.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.entity.BankUser;
import com.example.proxy.BankUserServiceProxy;

@RestController
public class BankUserConsumerController {

	@Autowired
	private BankUserServiceProxy bankUserServicerProxy;

	private Logger log = LoggerFactory.getLogger(BankUserConsumerController.class);

	@PostMapping("/users/create")
	public ResponseEntity<String> createUser(@RequestBody BankUser user) {
		log.debug("Creating a bank user");
		ResponseEntity<String> response = bankUserServicerProxy.createUser(user);
		log.debug("Created bank user: " + user);
		return response;
	}

	@GetMapping("/users/all")
	public ResponseEntity<List<BankUser>> getAllUsers() {
		log.debug("Fetching all bank users");
		ResponseEntity<List<BankUser>> response = bankUserServicerProxy.getAllUsers();
		log.debug("Fetched all bank users");
		return response;
	}

	@GetMapping("/users/{userId}")
	public ResponseEntity<BankUser> getUserById(@PathVariable("userId") Long userId) {
		log.debug("Fetching bank user by ID: " + userId);
		ResponseEntity<BankUser> response = bankUserServicerProxy.getUserById(userId);
		log.debug("Fetched bank user by ID: " + userId);
		return response;
	}

	@PostMapping("/users/approve/{userId}")
	public ResponseEntity<String> approveUser(@PathVariable("userId") Long userId) {
		log.debug("Approving bank user with ID: " + userId);
		ResponseEntity<String> response = bankUserServicerProxy.approveUser(userId);
		log.debug("Approved bank user with ID: " + userId);
		return response;
	}

	@DeleteMapping("/users/delete/{userId}")
	public ResponseEntity<String> deleteUser(@PathVariable("userId") Long userId) {
		log.debug("Deleting bank user with ID: " + userId);
		ResponseEntity<String> response = bankUserServicerProxy.deleteUser(userId);
		log.debug("Deleted bank user with ID: " + userId);
		return response;
	}
}
