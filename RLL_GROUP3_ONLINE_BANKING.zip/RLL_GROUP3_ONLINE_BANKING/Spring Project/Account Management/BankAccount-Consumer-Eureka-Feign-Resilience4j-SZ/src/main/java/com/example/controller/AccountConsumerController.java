package com.example.controller;

import com.example.entity.Account;
import com.example.proxy.AccountServiceProxy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/account-requests")
public class AccountConsumerController {

    @Autowired
    private AccountServiceProxy accountServiceProxy;

    private Logger log = LoggerFactory.getLogger(AccountConsumerController.class);

    @PostMapping("/create")
    public ResponseEntity<Account> createAccount(@RequestBody Account account) {
        log.debug("Creating an account");
        ResponseEntity<Account> response = accountServiceProxy.createAccount(account);
        log.debug("Created account: " + response.getBody());
        return response;
    }

    @PutMapping("/disable/{accountId}")
    public ResponseEntity<String> disableAccount(@PathVariable Long accountId) {
        log.debug("Disabling account with ID: " + accountId);
        ResponseEntity<String> response = accountServiceProxy.disableAccount(accountId);
        log.debug("Account disable response: " + response.getBody());
        return response;
    }

    @PutMapping("/enable/{accountId}")
    public ResponseEntity<String> enableAccount(@PathVariable Long accountId) {
        log.debug("Enabling account with ID: " + accountId);
        ResponseEntity<String> response = accountServiceProxy.enableAccount(accountId);
        log.debug("Account enable response: " + response.getBody());
        return response;
    }

    @GetMapping("/{accountId}")
    public ResponseEntity<Account> getAccount(@PathVariable Long accountId) {
        log.debug("Fetching account by ID: " + accountId);
        ResponseEntity<Account> response = accountServiceProxy.getAccount(accountId);
        log.debug("Fetched account: " + response.getBody());
        return response;
    }

    @GetMapping("/active")
    public ResponseEntity<List<Account>> getAllActiveAccounts() {
        log.debug("Fetching all active accounts");
        ResponseEntity<List<Account>> response = accountServiceProxy.getAllActiveAccounts();
        log.debug("Fetched all active accounts: " + response.getBody());
        return response;
    }

    @DeleteMapping("/delete/{accountNumber}")
    public ResponseEntity<String> deleteAccountByAccountNumber(@PathVariable int accountNumber) {
        log.debug("Deleting account with account number: " + accountNumber);
        ResponseEntity<String> response = accountServiceProxy.deleteAccountByAccountNumber(accountNumber);
        log.debug("Account deletion response: " + response.getBody());
        return response;
    }
}
