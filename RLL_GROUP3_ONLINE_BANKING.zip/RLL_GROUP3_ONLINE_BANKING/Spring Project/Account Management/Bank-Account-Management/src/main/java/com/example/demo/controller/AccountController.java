package com.example.demo.controller;

import com.example.demo.entity.Account;
import com.example.demo.service.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/accounts")
public class AccountController {

    @Autowired
    private AccountService accountService;

    @PostMapping("/create")
    public ResponseEntity<Account> createAccount(@RequestBody Account account) {
        Account newAccount = accountService.createAccount(account);
        return ResponseEntity.ok(newAccount);
    }

    @PutMapping("/disable/{accountId}")
    public ResponseEntity<String> disableAccount(@PathVariable Long accountId) {
        String result = accountService.disableAccount(accountId);
        if (result.equals("Account disabled")) {
            return ResponseEntity.ok(result);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PutMapping("/enable/{accountId}")
    public ResponseEntity<String> enableAccount(@PathVariable Long accountId) {
        String result = accountService.enableAccount(accountId);
        if (result.equals("Account enabled")) {
            return ResponseEntity.ok(result);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/{accountId}")
    public ResponseEntity<Account> getAccount(@PathVariable Long accountId) {
        Optional<Account> accountOptional = accountService.getAccountById(accountId);
        if (accountOptional.isPresent()) {
            Account account = accountOptional.get();
            return ResponseEntity.ok(account);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/active")
    public ResponseEntity<List<Account>> getAllActiveAccounts() {
        List<Account> activeAccounts = accountService.getAllActiveAccounts();
        return ResponseEntity.ok(activeAccounts);
    }

    @DeleteMapping("/delete/{accountNumber}")
    public ResponseEntity<String> deleteAccountByAccountNumber(@PathVariable int accountNumber) {
        accountService.deleteAccountByAccountNumber(accountNumber);
        return ResponseEntity.ok("Account deleted");
    }
}
