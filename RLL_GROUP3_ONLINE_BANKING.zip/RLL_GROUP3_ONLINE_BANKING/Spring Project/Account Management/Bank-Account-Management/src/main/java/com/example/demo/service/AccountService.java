package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Account;
import com.example.demo.repo.AccountRepository;

import java.util.List;
import java.util.Optional;

@Service
public class AccountService {

	@Autowired
	private AccountRepository accountRepository;
	
	private int lastGeneratedAccountNumber = 10000000;

	public Account createAccount(Account account) {
		Account newAccount = new Account();
		newAccount.setAccountNumber(generateAccountNumber());
		newAccount.setBalance(account.getBalance());
		newAccount.setActive(true);
		newAccount.setCustomerIdNumber(account.getCustomerIdNumber());

		return accountRepository.save(newAccount);
	}

	public String disableAccount(Long accountId) {
		Optional<Account> accountOptional = accountRepository.findById(accountId);

		if (accountOptional.isPresent()) {
			Account account = accountOptional.get();
			account.setActive(false);
			accountRepository.save(account);

			return "Account disabled";
		} else {
			return "No such account!"; 
		}
	}
	
	public String enableAccount(Long accountId) {
		Optional<Account> accountOptional = accountRepository.findById(accountId);

		if (accountOptional.isPresent()) {
			Account account = accountOptional.get();
			account.setActive(true);
			accountRepository.save(account);

			return "Account enabled";
		} else {
			return "No such account!"; 
		}
	}

	public Optional<Account> getAccountById(Long accountId) {
		return accountRepository.findById(accountId);
	}

	private int generateAccountNumber() {
		lastGeneratedAccountNumber++;
		return lastGeneratedAccountNumber;
	}
	
	 public List<Account> getAllActiveAccounts() {
	        return accountRepository.findByActive(true);
	 }
	 
	 public void deleteAccountByAccountNumber(int accountNumber) {
		    accountRepository.deleteByAccountNumber(accountNumber);
	}
}
